/***************************************************************************
 * Linux PPP over X - Generic PPP transport layer sockets
 * Linux PPP over Ethernet (PPPoE) Socket Implementation (RFC 2516)
 *
 * This file supplies definitions required by the PPP over Ethernet driver
 * (pppox.c).  All version information wrt this file is located in pppox.c
 *
 * License:
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 *
 */

#ifndef __LINUX_IF_PPPOX_H
#define __LINUX_IF_PPPOX_H


#include <asm/types.h>
#include <asm/byteorder.h>
#include <linux/version.h>

#ifdef  __KERNEL__
#include <linux/in.h>
#include <linux/if_ether.h>
#include <linux/if.h>
#include <linux/netdevice.h>
#include <linux/ppp_channel.h>
#endif /* __KERNEL__ */

/* For user-space programs to pick up these definitions
 * which they wouldn't get otherwise without defining __KERNEL__
 */
#ifndef AF_PPPOX
#define AF_PPPOX	24
#define PF_PPPOX	AF_PPPOX
#endif /* !(AF_PPPOX) */

/************************************************************************
 * PPPoE addressing definition
 */
typedef __u16 sid_t;
struct pppoe_addr{
       sid_t           sid;                    /* Session identifier */
       unsigned char   remote[ETH_ALEN];       /* Remote address */
       char            dev[IFNAMSIZ];          /* Local device to use */
};

struct pptp_addr{
       __u16           call_id;
       struct in_addr  sin_addr;
};
/************************************************************************
 * Protocols supported by AF_PPPOX
 */
#define PX_PROTO_OE    0 /* Currently just PPPoE */
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,22)
#define PX_PROTO_PPTP  1
#define PX_MAX_PROTO   2
#else
#define PX_PROTO_PPTP  2
#define PX_MAX_PROTO   3
#endif

struct sockaddr_pppox {
       sa_family_t     sa_family;            /* address family, AF_PPPOX */
       unsigned int    sa_protocol;          /* protocol identifier */
       union{
               struct pppoe_addr       pppoe;
	       			 struct pptp_addr        pptp;
       }sa_addr;
}__attribute__ ((packed));


/*********************************************************************
 *
 * ioctl interface for defining forwarding of connections
 *
 ********************************************************************/

#define PPPOEIOCSFWD	_IOW(0xB1 ,0, size_t)
#define PPPOEIOCDFWD	_IO(0xB1 ,1)
/*#define PPPOEIOCGFWD	_IOWR(0xB1,2, size_t)*/

/* Codes to identify message types */
#define PADI_CODE	0x09
#define PADO_CODE	0x07
#define PADR_CODE	0x19
#define PADS_CODE	0x65
#define PADT_CODE	0xa7
struct pppoe_tag {
	__u16 tag_type;
	__u16 tag_len;
	char tag_data[0];
} __attribute ((packed));

/* Tag identifiers */
#define PTT_EOL		__constant_htons(0x0000)
#define PTT_SRV_NAME	__constant_htons(0x0101)
#define PTT_AC_NAME	__constant_htons(0x0102)
#define PTT_HOST_UNIQ	__constant_htons(0x0103)
#define PTT_AC_COOKIE	__constant_htons(0x0104)
#define PTT_VENDOR 	__constant_htons(0x0105)
#define PTT_RELAY_SID	__constant_htons(0x0110)
#define PTT_SRV_ERR     __constant_htons(0x0201)
#define PTT_SYS_ERR  	__constant_htons(0x0202)
#define PTT_GEN_ERR  	__constant_htons(0x0203)

struct pppoe_hdr {
#if defined(__LITTLE_ENDIAN_BITFIELD)
	__u8 ver : 4;
	__u8 type : 4;
#elif defined(__BIG_ENDIAN_BITFIELD)
	__u8 type : 4;
	__u8 ver : 4;
#else
#error	"Please fix <asm/byteorder.h>"
#endif
	__u8 code;
	__u16 sid;
	__u16 length;
	struct pppoe_tag tag[0];
} __attribute__ ((packed));


/* Socket options */
#define PPTP_SO_TIMEOUT 1


#ifdef __KERNEL__
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
struct pppoe_opt {
	struct net_device      *dev;	  /* device associated with socket*/
	struct pppoe_addr	pa;	  /* what this socket is bound to*/
	struct sockaddr_pppox	relay;	  /* what socket data will be
					     relayed to (PPPoE relaying) */
};
#endif
struct pptp_opt {
	struct pptp_addr	src_addr;
	struct pptp_addr	dst_addr;
	__u32 ack_sent, ack_recv;
	__u32 seq_sent, seq_recv;
	int ppp_flags;
};
#define PPTP_FLAG_PAUSE 0
#define PPTP_FLAG_PROC 1

#include <net/sock.h>

struct pppox_sock {
	/* struct sock must be the first member of pppox_sock */
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	struct ppp_channel	chan;
	struct sock		*sk;
	#else
	struct sock		sk;
	struct ppp_channel	chan;
	#endif
	struct pppox_sock	*next;	  /* for hash table */
	union {
		struct pppoe_opt pppoe;
		struct pptp_opt pptp;
	} proto;
	unsigned short		num;
};
#define pppoe_dev	proto.pppoe.dev
#define pppoe_pa	proto.pppoe.pa
#define pppoe_relay	proto.pppoe.relay

static inline struct pppox_sock *pppox_sk(struct sock *sk)
{
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	return (struct pppox_sock *)sk->protinfo.pppox;
	#else
	return (struct pppox_sock *)sk;
	#endif
}

static inline struct sock *sk_pppox(struct pppox_sock *po)
{
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	return po->sk;
	#else
	return (struct sock *)po;
	#endif
}

struct module;

struct pppox_proto {
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24)
	int		(*create)(struct socket *sock);
	#else
	int		(*create)(struct net *net, struct socket *sock);
	#endif
	int		(*ioctl)(struct socket *sock, unsigned int cmd,
				 unsigned long arg);
  #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,15)
	struct module	*owner;
	#endif
};

extern int register_pppox_proto(int proto_num, struct pppox_proto *pp);
extern void unregister_pppox_proto(int proto_num);
extern void pppox_unbind_sock(struct sock *sk);/* delete ppp-channel binding */
extern int pppox_ioctl(struct socket *sock, unsigned int cmd, unsigned long arg);

/* PPPoX socket states */
enum {
    PPPOX_NONE		= 0,  /* initial state */
    PPPOX_CONNECTED	= 1,  /* connection established ==TCP_ESTABLISHED */
    PPPOX_BOUND		= 2,  /* bound to ppp device */
    PPPOX_RELAY		= 4,  /* forwarding is enabled */
    PPPOX_ZOMBIE	= 8,  /* dead, but still bound to ppp device */
    PPPOX_DEAD		= 16  /* dead, useless, please clean me up!*/
};

#endif /* __KERNEL__ */

#endif /* !(__LINUX_IF_PPPOX_H) */
